import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cg.mra.dao.AccountDao;
import com.cg.mra.dao.AccountDaoImpl;

public class Testcases {
     private AccountDao service;
	@Before
	public void setup(){
		service= new AccountDaoImpl();
	}
	
	
	@Test
	public void rechargeAccount() {
		
		 service.rechargeAccount("7731090265",40);
		 int amount =(int) service.findAll().get("7731090265").getAcountBalance();
		 //intialamount in mobile =50;
			assertTrue(90-amount==0);  //amount=50+40
		
		
	}

	@After
	public void tearDown(){
		service=null;
	}

}
