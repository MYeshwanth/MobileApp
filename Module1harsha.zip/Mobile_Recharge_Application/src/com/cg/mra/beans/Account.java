package com.cg.mra.beans;

public class Account {
	private String mobileNo;
	private String accountType;
	private String customerName;
	private double accountBalance;

	public Account(String mobileNo, String customerName) {
		this.mobileNo = mobileNo;
		this.customerName = customerName;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public String getAccountType() {
		return accountType;
	}
	public String getcustomerName(){
		return customerName;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public double getAcountBalance() {
		return accountBalance;
	}

	public void setAcountBalance(double accountBalance) {
		this.accountBalance = accountBalance;
	}
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "Your Current Balance is Rs."+accountBalance;
	}

}
