package com.cg.mra.service;

import java.util.HashMap;
import java.util.List;

import com.cg.mra.beans.Account;
import com.cg.mra.dao.AccountDao;
import com.cg.mra.dao.AccountDaoImpl;

public class AccountServiceImpl implements AccountService{
	
	private AccountDao accn;
	public AccountServiceImpl(){
		accn= new AccountDaoImpl();
	}
	
	
	@Override
	public Account getAccountDetails(String mobileNo) {
		// TODO Auto-generated method stub
		return accn.getAccountDetails(mobileNo);
	}

	@Override
	public int rechargeAccount(String mobileNo, double rechargeAmount) {
		// TODO Auto-generated method stub
		return accn.rechargeAccount(mobileNo, rechargeAmount);
	}


	@Override
	public HashMap<String,Account> findAll() {
		// TODO Auto-generated method stub
		return accn.findAll();
	}

}
