package com.cg.mra.ui;

import java.util.Scanner;

import com.cg.mra.service.AccountService;
import com.cg.mra.service.AccountServiceImpl;

public class MainUI {

	public static void main(String[] args) {

		AccountService service = new AccountServiceImpl();

		// System.out.println(service.findAll().get("7731090265")); //get the details of the acoount holder
		int ch;
		String mobileNo;
		int RechargeAmount;
		Scanner sc = new Scanner(System.in);
		while (true) {
			entryArguments();
			ch = sc.nextInt();
			switch (ch) {

			case 1://check for  amount in mobile
				System.out.print("Enter MobileNo : ");
				mobileNo = sc.next();
				try {
					if (service.findAll().get(mobileNo).getMobileNo().equals(mobileNo)) {
						System.out.println(
								"Your Current Balance is :" + service.findAll().get(mobileNo).getAcountBalance());
					}
				} catch (NullPointerException npe) {
					System.out.println("ERROR: Given Account id Does Not Exists");
					//entryArguments();
				}
				break;

			case 2: //check for  amount that is recharged
				System.out.print("Enter MobileNo : ");
				mobileNo = sc.next();
				System.out.print("Enter Recharge Amount: ");
				RechargeAmount = sc.nextInt();
				try {
					if (service.findAll().get(mobileNo).getMobileNo().equals(mobileNo)) {
						service.rechargeAccount(mobileNo, RechargeAmount);
						System.out.println("Your Account Recharged Succesfully :");
						System.out.println("Hello " + service.findAll().get(mobileNo).getcustomerName()
								+ ", Available Balance is " + service.findAll().get(mobileNo).getAcountBalance());
					}
				} catch (NullPointerException npe) {
					System.out.println("ERROR: Cannot Recharge Account as " + " Given Mobile No. Does Not Exists");
					//entryArguments();
					}
				break;

			case 3:
				System.exit(0);

			default:
				System.out.println("Please enter any of the integer to perform action");
				//entryArguments();
			}
		}
	}

	public static void entryArguments()  //Repeatedly asking options
	{
		System.out.println("Enter 1 to check your balance\n" + "Enter 2 to Recharge Account\n" + "Enter 3 to Exit\n");

	}
}
