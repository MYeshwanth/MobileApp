package com.cg.mra.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.cg.mra.beans.Account;

public class AccountDaoImpl implements AccountDao{
    
	private Map<String,Account> accdetails=new HashMap<>();
	
	
	
	public AccountDaoImpl(){
		Account acc=new Account("7731090265","Harsha");
		acc.setAccountType("IDEA");
		acc.setAcountBalance(50);
		accdetails.put(acc.getMobileNo(),acc);
		
		
		Account acc1=new Account("8731090267","Vardhan");
		acc1.setAccountType("Airtel");
		acc1.setAcountBalance(60);
		accdetails.put(acc1.getMobileNo(),acc1);
		
	}
	
	@Override
	public Account getAccountDetails(String mobileNo) {
		// TODO Auto-generated method stub
		return accdetails.get(mobileNo);
	}

	@Override
	public int rechargeAccount(String mobileNo, double rechargeAmount) {
		// TODO Auto-generated method stub
		int finalAmount=(int) (rechargeAmount+(accdetails.get(mobileNo).getAcountBalance()));
		accdetails.get(mobileNo).setAcountBalance(finalAmount);
		return finalAmount;
	}

	@Override
	public HashMap<String,Account> findAll() {
		// TODO Auto-generated method stub
		
		return (HashMap<String, Account>) accdetails;
	}
	

}
